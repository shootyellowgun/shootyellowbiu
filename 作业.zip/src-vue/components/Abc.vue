<template>
  <div class="abc">abc</div>
</template>

<script>
export default {};
</script>

<style scoped>
</style>
